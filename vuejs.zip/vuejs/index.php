<!DOCTYPE html>
<html>
<head>
	<title>Vue js learning</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width,initial-scale=1,shirnk-to-fit=no">

	<style type="text/css">
		 #overlay{
			position: fixed;
			top: 0;
			bottom: 0;
			left: 0;
			right: 0;
			background: rgba(0,0,0,0.6);
		}

	</style>

</head>
<body>
	<div id="app">
		<div class="conatiner-fluid">
			<div class="row bg-dark">
				<div class="col-lg-12">
					<p class="text-center text-light display-4 pt-2" style="font-size: 25px;"> CRUD APPLICATION USING VUE JS</p>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row mt-3">
				<div class="col-lg-6">
					<h3 class="text-info">Register User</h3>
				</div>
				<div class="col-lg-6">
					<button class="btn btn-info float-right" @click = "showAddModal=true">
						<i class="fa fa-user"></i>&nbsp;&nbsp;Add New User
					</button>
				</div>
			</div>
			<hr class="bg-info">
			<div class="alert alert-danger"  v-if="errorMsg">
				{{ errorMsg }}
			</div>
			<div class="alert alert-success" v-if="successMsg">
				{{ successMsg }}
			</div>

			<div class="row">
				<div class="col-lg-12">
					<table class="table table-bordered table-striped">
						<thead>
							<tr class="text-center bg-info text-light">
								<th>ID</th>
								<th>Name</th>
								<th>Email</th>
								<th>Password</th>
								<th>Edit</th>
								<th>Delete</th>
								<th>Disable</th>
							</tr>
						</thead>
						<tbody class="text-center" v-for = "emp in staff">
							<tr>
								<td>{{ emp.Staff_No }}</td>
								<td>{{ emp.Name }}</td>
								<td>{{ emp.Email }}</td>
								<td>{{ emp.Password }}</td>
								<td><a href="#" class="text-success" @click = "showEditModal=true; selectStaff(emp);"><i class="fas fa-edit">edit</i></a></td>
								<td><a href="#" class="text-danger"  @click = "showDeleteModal=true; selectStaff(emp); "><i class="fas fa-trash"></i></a></td>
							</tr>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- Overlay modal -->
			<div id="overlay" v-if="showAddModal" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Add New User</h5>
							<button type="button" class="close" @click = "showAddModal=false">
								<span aria-hidden="true">&times;</span>
							</button>
						</h5>
					</div>
					<div class="modal-body p-4">
						<div class="form">
							<div class="form-group">
								<input type="text" name="name" class="form-control form-control-lg" placeholder="Name" v-model="newStaff.name">
							</div>
							<div class="form-group">
								<input type="email" name="email" class="form-control form-control-lg" placeholder="Email" v-model="newStaff.email">
							</div>
							<div class="form-group">
								<input type="text" name="password" class="form-control form-control-lg" placeholder="Phone"  v-model="newStaff.password">
							</div>
							<div class="form-group">
								<button class="btn btn-info btn-block lg" 
										@click="showAddModal=false; addNewStaff();">
										<i class="fa fa-user">
										</i>
										&nbsp;&nbsp;Add User
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div id="overlay" v-if="showEditModal" >
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Edit User</h5>
								<button type="button" class="close" @click = "showEditModal=false">
									<span aria-hidden="true">&times;</span>
								</button>
							</h5>
						</div>
						<div class="modal-body p-4">
								<div class="form-group">
									<input type="hidden" name="Staff_No" class="form-control form-control-lg"  v-model="currentStaff.Staff_No">
									<input type="text" name="name" class="form-control form-control-lg"  v-model="currentStaff.Name">
								</div>
								<div class="form-group">
									<input type="email" name="email" class="form-control form-control-lg" v-model="currentStaff.Email">
								</div>
								<div class="form-group">
									<input type="text" name="password" class="form-control form-control-lg"  v-model="currentStaff.Password">
								</div>
								<div class="form-group">
										<button class="btn btn-info btn-block lg" @click ="showEditModal=false; updateStaff();"><i class="fa fa-user"></i>&nbsp;&nbsp;Update User</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>

		<!-- Delete user Modal -->

		<div id="overlay" v-if="showDeleteModal" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Delete User</h5>
							<button type="button" class="close" @click = "showDeleteModal=false">
								<span aria-hidden="true">&times;</span>
							</button>
						</h5>
					</div>
					<div class="modal-body p-4">
						<h4 class="text-danger"> Are you sure  to remove this user ? </h4>
						<h5> You are deleting </h5>
						<hr>
						<button type="button" class="btn btn-danger btn-lg"  @click = "showDeleteModal=false"> No </button>
						<button type="button" class="btn btn-success btn-lg"  @click = "showDeleteModal=false; deleteStaff();"> Yes</button>
						<hr>
					</div>
				</div>
			</div>
		</div>

			<!--  dialog end -->


		</div>
	</div> <!--  endoftheapp -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.min.js"></script>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/vue@2.6.0"></script>
	<script type="text/javascript" src="main.js">
		

	</script>
</body>
</html>