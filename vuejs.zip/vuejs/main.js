
var app = new Vue({
	el: '#app',
	data:{
		errorMsg: "",
		successMsg : "",
		showAddModal: false,
		showEditModal: false,
		showDeleteModal: false,
		staff : [],
		newStaff: { name: "", email: "", password: "" },
		currentStaff: {}
	},
	mounted: function(){
		this.getAllUsers();
	},
	methods: {
		getAllUsers(){
			axios.get("http://localhost/vuejs/process_Data.php?request=showAllStaff").then(function(response){
				if(response.data.error){
					app.errorMsg = response.data.message;
				}
				else{
					app.staff =  response.data.Staff;	
				}
			});
		},
		addNewStaff(){
			// var formData = app.toFormData(app.newStaff);

			let formData = new FormData();
			formData.append("name", this.newStaff.name);
			formData.append("email", this.newStaff.email);
			formData.append("password", this.newStaff.password);

			axios.post("http://localhost/vuejs/process_Data.php?request=addNewStaff", formData)
				.then(function(response){
					
				   	app.newStaff = {name :"",email: "", password:""};
					if(response.data.error){
						app.errorMsg = response.data.Message;
						console.log("error");
					}
					else {
						app.successMsg = response.data.Message;
						console.log("success");		
						app.getAllUsers();
					}
				})
				.catch(err => {
					console.log(err);
				});
		},

		updateStaff(){
			// var formData = app.toFormData(app.newStaff);

			let formData = new FormData();
			formData.append("Staff_No", this.currentStaff.Staff_No);
			formData.append("name", this.currentStaff.Name);
			formData.append("email", this.currentStaff.Email);
			formData.append("password", this.currentStaff.Password);

			axios.post("http://localhost/vuejs/process_Data.php?request=updateStaff", formData)
				.then(function(response){
					
				   	app.currentStaff = {Staff_No:"",name :"",email: "", password:""};
					if(response.data.error){
						app.errorMsg = response.data.Message;
						console.log("error");
					}
					else {
						app.successMsg = response.data.Message;
						console.log("success");		
						app.getAllUsers();
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		deleteStaff(){
			// var formData = app.toFormData(app.newStaff);

			let formData = new FormData();
			formData.append("Staff_No", this.currentStaff.Staff_No);
			formData.append("name", this.currentStaff.Name);
			formData.append("email", this.currentStaff.Email);
			formData.append("password", this.currentStaff.Password);

			axios.post("http://localhost/vuejs/process_Data.php?request=remove", formData)
				.then(function(response){
					
				   	app.currentStaff = {Staff_No:"",name :"",email: "", password:""};
					if(response.data.error){
						app.errorMsg = response.data.Message;
						console.log("error");
					}
					else {
						app.successMsg = response.data.Message;
						console.log("success");		
						app.getAllUsers();
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		selectStaff(staff){	
			app.currentStaff = staff;
			console.log(app.currentStaff);
		}
		
	}
});

