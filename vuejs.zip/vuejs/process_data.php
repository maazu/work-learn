<?php
 
 $request = htmlspecialchars($_GET["request"]);

 function connectDb(){
    $servername = "localhost";
    $username = "root";
    $password = "dog";
    try {
        $conn = new PDO("mysql:host=$servername;dbname=vue", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
        }
    catch(PDOException $e)
        {
        echo "Connection failed: " . $e->getMessage();
        }
}

if($request === 'showAllStaff'){
  echo getStaff();
}

else if($request === 'addNewStaff'){
  	$name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    if(checkUserExist($email) === 'USER EXIST'){
    	echo "Can not add the user ! Already Exist !";
    }
    else{
    	echo insertStaff($name,$email,$password);
    }
}

else if($request === 'updateStaff'){
	$Staff_No = $_POST['Staff_No'];
  	$name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    if(checkUserExist($email) === 'USER EXIST'){
    	echo updateStaff($Staff_No,$name,$email,$password);
    }
}



else if($request === 'remove'){
	$Staff_No = $_POST['Staff_No'];
	  $email = $_POST['email'];
    if(checkUserExist($email) === 'USER EXIST'){
    	 echo deleteStaff($Staff_No);
    }
}


function checkUserExist($email){
	$con= connectDb();
	$statement = $con->prepare('SELECT Email FROM Staff WHERE Email=:Email');
	$statement->execute(array(':Email' =>$email));
	if ($statement->rowCount() > 0) {
	    $success = "USER EXIST";
   		return $success;
	} else {
	    $error = "NOT EXIST";
   		return $error;
	}
}




function getStaff(){
	$con= connectDb();
    $staff_data = array('error' =>false);
    $result = $con->prepare("SELECT * From Staff");
    $result ->execute(); 
    $row = $result->fetchAll(PDO::FETCH_ASSOC);
   	$staff_data['Staff'] = $row;
    return json_encode($staff_data);
}

function insertStaff($name,$email,$password){
	$con= connectDb();
	$confirmation = array('error' =>false);
	$sql = "INSERT INTO `Staff` (`Name`,`Email`,`Password`) VALUES (:Name, :Email, :Password)";
	$statement = $con->prepare($sql);
	$statement->bindValue(':Name', $name);
	$statement->bindValue(':Email', $email);
	$statement->bindValue(':Password', $password);	 
	$inserted = $statement->execute();
	$success = 'New Staff has been added !';
	$confirmation['Message'] = $success;	
	$confirmation = json_encode($confirmation);	
	return $confirmation;
}


function updateStaff($Staff_No,$name,$email,$password){
	$con= connectDb();	
   	$sql = "UPDATE Staff SET Name=?, Email=?, Password=? WHERE Staff_No=?";
	$statement = $con->prepare($sql);
	$statement->execute([$name, $email, $password, $Staff_No]);
	$success = 'Details Update!';
	$confirmation['Message'] = $success;	
	$confirmation = json_encode($confirmation);	
	return $confirmation;
}



function deleteStaff($Staff_No){
	$con= connectDb();
	$confirmation = array('error' => false);
	$sql = "DELETE FROM `Staff` WHERE `Staff_No` = :Staff_No";
	$statement = $con->prepare($sql);	 
	$delete_staff = $Staff_No;
	$statement->bindValue(':Staff_No', $delete_staff);
	$statement->execute();
	$success = 'Deleted Successfully !';
	$confirmation['Message'] = $success;	
	$confirmation = json_encode($confirmation);	
	return $confirmation;
}




 ?>